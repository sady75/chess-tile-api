from flask import Flask, request, jsonify
import tensorflow as tf
from PIL import Image
import numpy as np
import io

app = Flask(__name__)
model = tf.keras.models.load_model("model/model.h5")
class_names = ['b_bishop', 'b_king', 'b_knight', 'b_pawn', 'b_queen', 'b_rook',
               'w_bishop', 'w_king', 'w_knight', 'w_pawn', 'w_queen', 'w_rook', 'empty']

@app.route("/predict", methods=["POST"])
def predict():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400
    image_file = request.files["image"]
    image = Image.open(image_file).resize((224, 224))
    image = np.array(image) / 255.0
    image = np.expand_dims(image, axis=0)
    predictions = model.predict(image)
    label = class_names[np.argmax(predictions[0])]
    confidence = float(np.max(predictions[0]))
    return jsonify({"label": label, "confidence": confidence})
